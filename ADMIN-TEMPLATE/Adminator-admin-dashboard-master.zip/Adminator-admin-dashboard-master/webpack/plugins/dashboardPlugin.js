const
  DashboardPlugin = require('webpack-dashboard/plugin');

module.exports = new DashboardPlugin();
